<?php

namespace App\Http\Controllers;

use App\Models\Brands;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Tag;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    function AddProduct(){
        $categories = Category::all();
        $subcategories = Subcategory::all();
        $brands = Brands::all();
        $tags = Tag::all();
        return view('admin.products.add_product', [
            'categories'=> $categories,
            'subcategories'=> $subcategories,
            'brands'=> $brands,
            'tags'=> $tags
        ]);
    }
}
