// tempusdominus-bootstrap-4
$(function() {
  'use strict';

  $('#datetimepickerExample').datetimepicker({
    format: 'LT'
  });
});