<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Add New Product</h3>
                    </div>
                    <div class="card-body">
                        <form action="" method="" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-3">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Select Category</label>
                                        <select name="" id="" class="form-select">
                                            <option value="" disabled selected>Select One</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Select Sub Category</label>
                                        <select name="" id="" class="form-select">
                                            <option value="" disabled selected>Select One</option>
                                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->subcategory); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Select Brand</label>
                                        <select name="" id="" class="form-select">
                                            <option value="" disabled selected>Select One</option>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Product Code(SKU)</label>
                                        <input type="text" name="sku" class="form-control">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Enter Product Name</label>
                                        <input type="text" name="product-name" class="form-control">
                                    </div>
                                </div>

                                <div class="col-lg-2">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Select Discount</label>
                                        <select name="" id="" class="form-select">
                                            <option value="" disabled selected>Select One</option>
                                            <?php for($i = 1; $i < 100; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i. '%'); ?></option>

                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Enter Short Description</label>
                                        <textarea name="" id="" cols="30" rows="3" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Enter Long Description</label>
                                        <textarea name="" id="summernote" cols="30" rows="10" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Enter Additional Info</label>
                                        <textarea name="" id="summernote2" cols="30" rows="10" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Enter Tags</label>
                                        <select id="select-gear" class="demo-default" name="tag_name[]" multiple placeholder="Select tag...">
                                            <option value="">Select tags...</option>
                                            <optgroup label="">
                                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                          </select>

                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Preview Image</label>
                                        <input type="file" name="preview" class="form-control">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="mb-5">
                                        <label for="" class="form-label">Gallery Images</label>
                                        <input type="file" name="gallery[]" class="form-control">
                                    </div>
                                </div>

                                <div class="col-lg-6 m-auto">
                                    <div class="mb-5">
                                        <button class="btn btn-primary d-block m-auto">Add Product</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
        <script>
            $(document).ready(function() {

              $('#summernote').summernote();
              $('#summernote2').summernote();

              $('#select-gear').selectize({ sortField: 'text' })
            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/admin/products/add_product.blade.php ENDPATH**/ ?>