<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-10">
            <?php if(session('restored')): ?>
                <div class="alert alert-success"><?php echo e(session('restored')); ?></div>
            <?php endif; ?>
            <?php if(session('force_delete')): ?>
                <div class="alert alert-danger"><?php echo e(session('force_delete')); ?></div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h3>Trashed Tags</h3>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <tr>
                            <th>SL</th>
                            <th>Tag</th>
                            <th>Deleted At</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=>$tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($sl+1); ?></td>
                            <td><?php echo e($tag->tag_name); ?></td>
                            <td><?php echo e($tag->deleted_at->diffForHumans()); ?></td>
                            <td>
                                <a title="Restore" href="<?php echo e(route('restore.tag', $tag->id)); ?>" class="edit btn btn-success btn-icon"><i data-feather="rotate-cw"></i></a>
                                <a title="Permanent Delete" data-id="<?php echo e($tag->id); ?>" data-name="<?php echo e($tag->tag_name); ?>" class="delete btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
                // delete
        $('.delete').on('click', function(){
            let id = $(this).data('id');
            let name = $(this).data('name');
            let deleteUrl = "<?php echo e(route('tag.delete.permanent', ['id' => ':id'])); ?>";
            deleteUrl = deleteUrl.replace(':id', id);

            Swal.fire({
                title: "Are you sure?",
                text: "You Want TO Delete The Tag '" + name + "'",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, I will Delete!"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/admin/tags/tags_trash.blade.php ENDPATH**/ ?>