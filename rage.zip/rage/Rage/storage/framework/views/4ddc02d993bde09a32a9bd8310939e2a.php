<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-header"><h2 class="h2 m-auto">Sub Categories</h2></div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-danger text-center"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo e($category->name); ?></h3>
                                </div>
                                <div class="card-body">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Subcategory</th>
                                            <th>Updated At</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php $__currentLoopData = App\Models\Subcategory::where('category_id', $category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($subcategory->subcategory); ?></td>
                                            <td><?php echo e($subcategory->updated_at == null ? '' : $subcategory->updated_at->diffForHumans()); ?></td>
                                            <td>
                                                <a title="Edit <?php echo e($subcategory->subcategory); ?>" data-subcategory="<?php echo e(json_encode(['id' => $subcategory->id, 'subcategory' => $subcategory->subcategory])); ?>" class="edit btn btn-primary shadow btn-xs sharp"><i class="fa fa-edit"></i></a>
                                                <a title="Delete <?php echo e($subcategory->subcategory); ?>" data-id="<?php echo e($subcategory->id); ?>" data-name="<?php echo e($subcategory->subcategory); ?>" class="delete btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        // delete
        $('.delete').on('click', function(){
            let id = $(this).data('id');
            let name = $(this).data('name');
            let deleteUrl = "<?php echo e(route('delete.subcategory', ['id' => ':id'])); ?>";
            deleteUrl = deleteUrl.replace(':id', id);

            Swal.fire({
                title: "Are you sure?",
                text: "You Want TO Delete The Subcategory '" + name + "'",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, I will Delete!"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        });


        // edit

        $('.edit').on('click', function(){
            let subcategoryData = $(this).data('subcategory');
            let id = subcategoryData.id;
            let subcategory = subcategoryData.subcategory;

            let editUrl = "<?php echo e(route('subcategory.edit', ['id' => ':id'])); ?>";
            editUrl = editUrl.replace(':id', id);
            let csrfToken = document.head.querySelector('meta[name="csrf-token"]').content;

            Swal.fire({
                title: "Edit '"+ subcategory + "'",
                html:
                    `<label for="subcategory">Update Subcategory</label>
                    <input type="text" id="subcategory" name="subcategory" class="swal2-input" placeholder="Enter input 1" value="${subcategory}">
                    `,
                showCancelButton: true,
                confirmButtonColor: "#28a745",
                cancelButtonColor: "#d33",
                confirmButtonText: "Save",
            }).then((result) => {
                if (result.isConfirmed) {
                    // Access input values
                    let subcategoryValue = document.getElementById('subcategory').value;

                    // Create a FormData object to send the data
                    let formData = new FormData();
                    formData.append('_token', csrfToken);
                    formData.append('id', id);
                    formData.append('subcategory', subcategoryValue);
                    // Use fetch to send the data to the server
                    $.ajax({
                        type: 'POST',
                        url: editUrl, // Laravel route for handling the update
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {
                           // Handle success response
                                console.log('Update successful');

                        // Show a customized success message with SweetAlert2
                        Swal.fire({
                            title: 'Success',
                            text: 'Category updated successfully',
                            icon: 'success',
                            confirmButtonColor: '#28a745',
                        }).then((result) => {
                            // Optionally, perform actions after the user clicks the "OK" button
                            if (result.isConfirmed) {
                                location.reload(); // Reload the page or perform other actions
                            }
                        });
                        // Add an event listener to the SweetAlert modal overlay
                        document.querySelector('.swal2-container').addEventListener('click', function(event) {
                            // Check if the click is outside the modal (overlay)
                            if (event.target.classList.contains('swal2-container')) {
                                location.reload(); // Reload the page or perform other actions
                            }
                        });
                        },
                        error: function(xhr, status, error) {
                        // Handle error
                        console.error(error);

                        // Check if the error is a validation error
                        if (xhr.status === 422) {
                            // Parse the validation errors from the response JSON
                            var validationErrors = JSON.parse(xhr.responseText);

                            // Display the validation errors to the user

                            for (var field in validationErrors.errors) {
                                var message = validationErrors.errors[field].join(', ') + '\n';
                            }

                            alert(message);
                        } else {
                            // For other types of errors, show a generic error message
                            alert('An error occurred. Please try again later.');
                        }
                    },
                        complete: function() {
                            // This block will be executed after success or error
                            // You can use it for actions that need to be performed in either case
                            console.log('Request completed');
                        }
                    });

                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/admin/subcategory.blade.php ENDPATH**/ ?>