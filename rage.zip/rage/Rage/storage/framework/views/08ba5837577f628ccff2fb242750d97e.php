<?php $__env->startSection('content'); ?>
    <div class="row">
       <div class="col-lg-4">
            <div class="card">
                <div class="card-header">Edit Profile Information</div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('updateprofile')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="name" value="<?php echo e(Auth::user()->name); ?>" name="name" class="form-control" id="">
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
       </div>

       <div class="col-lg-4">
            <div class="card">
                <div class="card-header">Edit Password</div>
                <div class="card-body">
                    <?php if(session('pass_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('pass_success')); ?></div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('update.password')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                        <label class="form-label">Current Password</label>
                        <input type="password" value="<?php echo e(old('currentpass')); ?>" name="currentpass" class="form-control" id="">
                        <?php $__errorArgs = ['currentpass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php if(session('match')): ?>
                            <strong class="text-danger"><?php echo e(session('match')); ?></strong>
                        <?php endif; ?>
                        </div>
                        <div class="mb-3 pass">
                        <label class="form-label">New Password</label>
                        <input type="password" value="" name="password" class="form-control" class="password" id="password">
                        <i class="fas fa-eye"></i>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 pass">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" value="" name="password_confirmation" class="form-control" id="confirmPass">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
       </div>

       <div class="col-lg-3">
            <div class="card">
                <div class="card-header">Update Profile Photo</div>
                <div class="card-body">
                    <?php if(session('photo_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('photo_success')); ?></div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('update.photo')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3 pass">

                        <?php if(Auth::user()->photo == null): ?>
                            <img height="200" id="blah" src="<?php echo e(Avatar::create(Auth::user()->name)->toBase64()); ?>" alt="">
                        <?php else: ?>
                            <img src="<?php echo e(asset(Auth::user()->photo)); ?>" height="200" id="blah" alt="">
                        <?php endif; ?>

                        </div>

                        <div class="mb-3 pass">
                        <label class="form-label">Choose Image</label>
                        <input type="file" value="" name="image" class="form-control" id="confirmPass" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .pass{
        position: relative;
    }
    .pass i {
    cursor: pointer;
    position: absolute;
    top: 40px;
    right: 10px;
    }
</style>

<?php $__env->startSection('script'); ?>
$('.pass i').click(function () {
    var PassInput = $('#password');
    var ConfirmInput = $('#confirmPass');

    // Check the current type and toggle it
    if (PassInput.attr('type') === 'password') {
        PassInput.attr('type', 'text');
        ConfirmInput.attr('type', 'text');
    } else {
        PassInput.attr('type', 'password');
        ConfirmInput.attr('type', 'password');
    }
});
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/admin/user_profile.blade.php ENDPATH**/ ?>