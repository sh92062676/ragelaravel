<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-10 m-auto">
            <form id="select_form" action="<?php echo e(route('subcategory.select.trash')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(session('restored')): ?>
                    <div class="alert alert-success"><?php echo e(session('restored')); ?></div>
                <?php endif; ?>
                <?php if(session('force_delete')): ?>
                    <div class="alert alert-warning"><?php echo e(session('force_delete')); ?></div>
                <?php endif; ?>
                <?php if(session('selected_restore')): ?>
                <div class="alert alert-success"><?php echo e(session('selected_restore')); ?></div>
                <?php endif; ?>
                <?php if(session('selected_delete')): ?>
                    <div class="alert alert-danger"><?php echo e(session('selected_delete')); ?></div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h3>Subcategory Trash List</h3>
                        <button type="submit" value="restore" name="btn" id="restore_btn" style= "height: 31px; width: 128px; line-height: 2px;margin-right: -577px;" class="btn btn-success d-none restore_btn">Restore All</button>
                        <button type="submit" value="delete" name="btn" id="delete_btn" style= "height: 31px; width: 128px; line-height: 2px;" class="btn btn-danger d-none delete_btn">Delete All</button>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderd">
                            <tr>
                                <th>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input id="SelectAll" title="Select All" type="checkbox" class="form-check-input">
                                        <i class="input-frame"></i></label>
                                    </div>
                                </th>
                                <th>SL</th>
                                <th>Subcategory</th>
                                <th>Category</th>
                                <th>Deleted At</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=>$subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $category = App\Models\Category::find($subcategory->category_id);
                            ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input title="Select" type="checkbox" name="subcategories_id[]" value="<?php echo e($subcategory->id); ?>" class="select-one form-check-input">
                                        <i class="input-frame"></i></label>
                                    </div>
                                </td>
                                <td><?php echo e($sl+1); ?></td>
                                <td><?php echo e($subcategory->subcategory); ?></td>
                                <td>
                                    <?php if(empty($category)): ?>
                                    <?php echo e(App\Models\Category::onlyTrashed()->find($subcategory->category_id)->name); ?>

                                    <?php else: ?>
                                    <?php echo e($category->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($subcategory->deleted_at->diffForHumans()); ?></td>
                                <td>
                                    <a title="Restore <?php echo e($subcategory->subcategory); ?>" href="<?php echo e(route('restore.subcategory', ['id'=> $subcategory->id])); ?>" data-category="" class="edit btn btn-success btn-icon"><i data-feather="rotate-cw"></i></a>
                                    <a title="Delete <?php echo e($subcategory->subcategory); ?>" data-id="<?php echo e($subcategory->id); ?>" data-name="<?php echo e($subcategory->subcategory); ?>" class="delete btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        // delete
        $('.delete').on('click', function(){
            let id = $(this).data('id');
            let name = $(this).data('name');
            let deleteUrl = "<?php echo e(route('subcategory.force.delete', ['id' => ':id'])); ?>";
            deleteUrl = deleteUrl.replace(':id', id);

            Swal.fire({
                title: "Are you sure?",
                text: "You Want To Permanently Delete The Subcategory '" + name + "'",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, I will Delete!"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        });

                    // If All Box Be Checked SelectAll Will Be Checked

        $(".select-one").on('change', function() {
        var allChecked = $(".select-one:checked").length === $(".select-one").length;
        $("#SelectAll").prop("checked", allChecked);

        var anySelected = $(".select-one:checked").length > 0;
        $("#delete_btn").toggleClass("d-none", !anySelected);
        $("#restore_btn").toggleClass("d-none", !anySelected);
        });
        // Check All
        $("#SelectAll").on('click', function(){
        this.checked ? $(".select-one").prop("checked",true) : $(".select-one").prop("checked",false);

        var anySelected = $(".select-one:checked").length > 0;
        $("#delete_btn").toggleClass("d-none", !anySelected);
        $("#restore_btn").toggleClass("d-none", !anySelected);
        })

                    // delete Sweet Alert
            $("#delete_btn").on('click', function(e) {
                e.preventDefault(); // Prevent the default form submission

                // Use SweetAlert to show a confirmation popup
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You want to delete Selected Subcategories. You won\'t be able to revert this!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // If user confirms, submit the form
                        $("#select_form").submit();
                    }
                });
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/admin/subcategory/subcategory_trash.blade.php ENDPATH**/ ?>