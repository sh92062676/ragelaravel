<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <H1 style="text-align: center; margin-top:100px;">Ok This is Laravel Project</H1>
</body>
</html><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/Home.blade.php ENDPATH**/ ?>