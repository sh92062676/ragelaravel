<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-10 m-auto">
            <div class="card">
                <div class="card-header text-center">User List</div>
                <div class="card-body">
                    <?php if(session('delete')): ?>
                        <div class="alert alert-success"><?php echo e(session('delete')); ?></div>
                    <?php endif; ?>
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">SL</th>
                            <th scope="col">photo</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                              <td><?php echo e($sl+1); ?></td>
                              <td><img src="<?php echo e($user->photo != null ? (asset($user->photo)) : Avatar::create($user->name)->toBase64()); ?>" alt=""></td>
                              <td><?php echo e($user->name); ?></td>
                              <td><?php echo e($user->email); ?></td>
                              <td>
                                <a data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>"  class="delete btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
                              </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
                $('.delete').on('click', function(){
            let id = $(this).data('id');
            let name = $(this).data('name');
            let deleteUrl = "<?php echo e(route('user.delete', ['id' => ':id'])); ?>";
            deleteUrl = deleteUrl.replace(':id', id);

            Swal.fire({
                title: "Are you sure?",
                text: "You Want TO Delete The User '" + name + "'",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, I will Delete!"
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\resources\views/admin/user/userlist.blade.php ENDPATH**/ ?>