<?php echo e($slot); ?>

<?php /**PATH C:\Users\Shamim\Desktop\rage\Rage\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>